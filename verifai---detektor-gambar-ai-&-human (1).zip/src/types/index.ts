export interface GeneratorScore {
  name: string;
  score: number;
}

export interface DetectionOutput {
  ai_score: number;
  label: 'ai' | 'human';
  top_generator: string;
  generator_scores: GeneratorScore[];
  provider?: string;
}

export interface ScanRecord {
  id: string;
  userId: string;
  imageUrl: string;
  thumbnailUrl?: string;
  fileName: string;
  fileSize: number;
  aiScore: number;
  label: 'ai' | 'human';
  topGenerator: string;
  generatorScores: GeneratorScore[];
  createdAt: number;
  provider?: string;
}

export interface UserNotificationPreferences {
  emailScanResults: boolean;
  emailProductUpdates: boolean;
  securityAlerts: boolean;
}

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  preferences?: UserNotificationPreferences;
}

export interface SimilarArtwork {
  id: string;
  title: string;
  generator: string;
  similarity: number;
  previewUrl: string;
  styleTag: string;
  promptSnippet: string;
}

export interface WebSearchSource {
  title: string;
  url: string;
}

export interface RealtimeAiMatchResult {
  topMatchedModel: string;
  matchConfidence: number; // 0 - 100
  aestheticProfile: string;
  modelFamily: string; // e.g. "Diffusion Latent Model", "Flow-Matching Transformer"
  identifiedSignatures: string[];
  reconstructedPrompt: string;
  similarArtworks: SimilarArtwork[];
  searchSources: WebSearchSource[];
  analysisSummary: string;
}

export interface VeoGenerationConfig {
  aspectRatio: '16:9' | '9:16';
  prompt?: string;
}

export type NavigationTab =
  | 'dashboard'
  | 'upload'
  | 'search-match'
  | 'veo-animate'
  | 'history'
  | 'insight'
  | 'profile';
