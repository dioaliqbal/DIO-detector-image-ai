import React, { useState, useRef } from 'react';
import { ScanRecord, NavigationTab } from '../../types';
import { BrandLogo } from '../common/BrandLogo';
import {
  Film,
  Play,
  Download,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Layers,
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  Video,
} from 'lucide-react';

interface VeoAnimatePageProps {
  scans: ScanRecord[];
  activeImage?: { url: string; file?: File; name: string } | null;
  onNavigate: (tab: NavigationTab) => void;
}

export const VeoAnimatePage: React.FC<VeoAnimatePageProps> = ({
  scans,
  activeImage,
  onNavigate,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [imageUrl, setImageUrl] = useState<string | null>(
    activeImage?.url || scans[0]?.imageUrl || null
  );
  const [imageName, setImageName] = useState<string>(
    activeImage?.name || scans[0]?.fileName || 'Gambar Pilihan'
  );
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [prompt, setPrompt] = useState<string>(
    'Cinematic slow camera zoom in with atmospheric light particle animation'
  );
  const [generating, setGenerating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const presets = [
    'Cinematic slow camera zoom with soft ambient lighting',
    'Gentle atmospheric breeze, subtle hair and textile motion',
    'Slow panning camera with volumetric light beam shifting',
    'Subtle dynamic lighting with floating luminous dust particles',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setImageUrl(reader.result as string);
        setVideoBlobUrl(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartGeneration = async () => {
    if (!imageUrl) {
      setError('Silakan pilih atau unggah gambar terlebih dahulu.');
      return;
    }

    setGenerating(true);
    setError(null);
    setVideoBlobUrl(null);
    setStatusMessage('Menginisialisasi model Veo (veo-3.1-fast-generate-preview)...');

    try {
      // Step 1: Start Generation
      const cleanBase64 = imageUrl.includes(',') ? imageUrl.split(',')[1] : imageUrl;
      const startRes = await fetch('/api/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Data: cleanBase64,
          mimeType: 'image/jpeg',
          prompt,
          aspectRatio,
        }),
      });

      if (!startRes.ok) {
        throw new Error(`Gagal memulai generasi video (Status ${startRes.status})`);
      }

      const { operationName } = await startRes.json();
      setStatusMessage('Memproses sintesis frame video dan vektor gerakan...');

      // Step 2: Poll Status
      let isDone = false;
      let attempts = 0;
      while (!isDone && attempts < 40) {
        await new Promise((r) => setTimeout(r, 2000));
        attempts++;
        setStatusMessage(`Merender animasi video... (${attempts * 2}s)`);

        const pollRes = await fetch('/api/video-status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ operationName }),
        });

        if (pollRes.ok) {
          const pollData = await pollRes.json();
          if (pollData.done) {
            isDone = true;
          }
        }
      }

      // Step 3: Download Video Stream
      setStatusMessage('Mengunduh hasil video MP4 kualitas tinggi...');
      const downloadRes = await fetch('/api/video-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operationName }),
      });

      if (!downloadRes.ok) {
        throw new Error('Gagal mengunduh file video yang selesai di-render');
      }

      const videoBlob = await downloadRes.blob();
      const generatedUrl = URL.createObjectURL(videoBlob);
      setVideoBlobUrl(generatedUrl);
      setStatusMessage('Video selesai di-generate!');
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Terjadi kesalahan saat merender video.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold tracking-tight text-[#1E2E42]">
            Ubah Foto Jadi Video (Veo)
          </h1>
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#1E2E42] bg-[#F0F4F8] border border-[#CBD5E1] px-2.5 py-0.5 rounded-full">
            <Film className="w-3 h-3" />
            Veo Video Generator
          </span>
        </div>
        <p className="text-sm text-zinc-500">
          Mau fotomu bergerak hidup? Tinggal pilih foto dan tentukan gerakan kamera yang kamu mau.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Image & Config */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-zinc-200 p-6 shadow-xs space-y-6">
          {/* Target Image Preview & Selector */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-600">
                Gambar Acuan (Source Frame)
              </span>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs text-[#1E2E42] hover:underline font-medium cursor-pointer"
              >
                Unggah Foto Baru
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            {imageUrl ? (
              <div className="relative rounded-xl overflow-hidden border border-zinc-200 bg-zinc-900/5 aspect-16/9 flex items-center justify-center">
                <img
                  src={imageUrl}
                  alt={imageName}
                  className="max-h-full max-w-full object-contain"
                />
                <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[11px] px-2 py-0.5 rounded-md truncate max-w-[80%]">
                  {imageName}
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-300 rounded-xl p-8 text-center cursor-pointer hover:bg-zinc-50"
              >
                <UploadCloud className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
                <span className="text-xs font-semibold text-zinc-700 block">
                  Pilih foto untuk dianimasikan
                </span>
              </div>
            )}

            {/* Quick history selector */}
            {scans.length > 0 && (
              <div className="pt-2">
                <span className="text-[11px] text-zinc-500 block mb-1.5">
                  Atau ambil dari histori scan Anda:
                </span>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {scans.slice(0, 6).map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setImageUrl(s.imageUrl);
                        setImageName(s.fileName);
                        setVideoBlobUrl(null);
                      }}
                      className="shrink-0 w-14 h-14 rounded-lg overflow-hidden border border-zinc-200 hover:border-[#1E2E42] transition-colors"
                    >
                      <img
                        src={s.thumbnailUrl || s.imageUrl}
                        alt={s.fileName}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Aspect Ratio Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-zinc-700 uppercase tracking-wider">
              Aspek Rasio Video
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setAspectRatio('16:9')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                  aspectRatio === '16:9'
                    ? 'bg-[#F0F4F8] border-[#1E2E42] text-[#1E2E42]'
                    : 'bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50'
                }`}
              >
                <div className="w-4 h-2.5 border border-current rounded-xs" />
                <span>16:9 (Landscape)</span>
              </button>
              <button
                type="button"
                onClick={() => setAspectRatio('9:16')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                  aspectRatio === '9:16'
                    ? 'bg-[#F0F4F8] border-[#1E2E42] text-[#1E2E42]'
                    : 'bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50'
                }`}
              >
                <div className="w-2.5 h-4 border border-current rounded-xs" />
                <span>9:16 (Portrait / Reels)</span>
              </button>
            </div>
          </div>

          {/* Motion Prompt Input */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-zinc-700 uppercase tracking-wider">
              Arahan Gerakan Kamera & Animasi (Prompt)
            </label>
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Jelaskan jenis gerakan kamera, pergerakan cahaya, atau elemen objek yang ingin dianimasikan..."
              className="w-full p-3 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-[#1E2E42] focus:bg-white transition-colors"
            />
            {/* Presets */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(preset)}
                  className="text-[10px] text-zinc-600 bg-zinc-100 hover:bg-zinc-200 px-2 py-1 rounded-md transition-colors cursor-pointer"
                >
                  + {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Trigger Button */}
          <button
            onClick={handleStartGeneration}
            disabled={generating || !imageUrl}
            className="w-full py-3 px-5 bg-[#1E2E42] hover:bg-[#162332] text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-xs"
          >
            {generating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Sedang Merender Video Veo...</span>
              </>
            ) : (
              <>
                <Film className="w-4 h-4" />
                <span>Generate Video dengan Veo AI</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </div>

        {/* Right Column: Video Output Player */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-zinc-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-600 flex items-center gap-1.5">
              <Video className="w-4 h-4 text-[#1E2E42]" />
              <span>Hasil Render Video</span>
            </span>
            {videoBlobUrl && (
              <a
                href={videoBlobUrl}
                download={`verifai-veo-${Date.now()}.mp4`}
                className="inline-flex items-center gap-1 text-xs text-[#1E2E42] hover:underline font-semibold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download MP4</span>
              </a>
            )}
          </div>

          {/* Video Container */}
          <div
            className={`rounded-xl overflow-hidden border border-zinc-200 bg-zinc-950 flex items-center justify-center relative ${
              aspectRatio === '9:16' ? 'aspect-9/16 max-h-[500px]' : 'aspect-16/9'
            }`}
          >
            {videoBlobUrl ? (
              <video
                src={videoBlobUrl}
                controls
                autoPlay
                loop
                playsInline
                className="w-full h-full object-contain"
              />
            ) : generating ? (
              <div className="p-6 text-center text-zinc-300 space-y-3">
                <div className="w-10 h-10 border-2 border-white/20 border-t-white rounded-full animate-spin mx-auto" />
                <p className="text-xs font-medium text-white">{statusMessage}</p>
                <p className="text-[11px] text-zinc-400">
                  Model Veo memprediksi kontinuitas temporal antar piksel
                </p>
              </div>
            ) : (
              <div className="p-8 text-center text-zinc-500 space-y-2">
                <Play className="w-8 h-8 text-zinc-600 mx-auto" />
                <span className="text-xs font-semibold block text-zinc-400">
                  Belum Ada Video yang Dibuat
                </span>
                <p className="text-[11px] text-zinc-500 max-w-xs mx-auto">
                  Klik "Generate Video" di sebelah kiri untuk menghasilkan video dari gambar Anda.
                </p>
              </div>
            )}
          </div>

          {statusMessage && generating && (
            <div className="p-3 rounded-lg bg-zinc-50 border border-zinc-200 text-xs text-zinc-700 flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 text-[#1E2E42] animate-spin shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-lg bg-zinc-100 border border-zinc-300 text-xs text-zinc-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-[#1E2E42] shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
