import React, { useState } from 'react';
import { ScanRecord, RealtimeAiMatchResult, NavigationTab } from '../../types';
import { BrandLogo } from '../common/BrandLogo';
import {
  Search,
  Sparkles,
  ExternalLink,
  Layers,
  ArrowRight,
  Film,
  RefreshCw,
  Copy,
  Check,
  Cpu,
  Globe,
  Sliders,
  Image as ImageIcon,
} from 'lucide-react';

interface SearchMatchPageProps {
  scans: ScanRecord[];
  activeImage?: { url: string; file?: File; name: string } | null;
  onNavigate: (tab: NavigationTab) => void;
  onSelectForVeo?: (imageUrl: string, name: string) => void;
}

export const SearchMatchPage: React.FC<SearchMatchPageProps> = ({
  scans,
  activeImage,
  onNavigate,
  onSelectForVeo,
}) => {
  const [selectedScanId, setSelectedScanId] = useState<string>(
    activeImage ? 'custom' : scans[0]?.id || ''
  );
  const [customImageUrl, setCustomImageUrl] = useState<string | null>(
    activeImage?.url || (scans[0]?.imageUrl || null)
  );
  const [customImageName, setCustomImageName] = useState<string>(
    activeImage?.name || (scans[0]?.fileName || 'Gambar Pilihan')
  );
  const [searchNotes, setSearchNotes] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [matchResult, setMatchResult] = useState<RealtimeAiMatchResult | null>(null);
  const [copiedPrompt, setCopiedPrompt] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Convert image URL or File to base64
  const urlToBase64 = async (url: string): Promise<string> => {
    if (url.startsWith('data:')) {
      return url.split(',')[1];
    }
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        resolve(res.includes(',') ? res.split(',')[1] : res);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const handleRunSearch = async () => {
    if (!customImageUrl) {
      setError('Silakan pilih gambar terlebih dahulu');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const base64Data = await urlToBase64(customImageUrl);
      const res = await fetch('/api/realtime-ai-match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Data,
          mimeType: 'image/jpeg',
          customQuery: searchNotes,
        }),
      });

      if (!res.ok) {
        throw new Error(`Gagal melakukan pencarian real-time (Status ${res.status})`);
      }

      const data: RealtimeAiMatchResult = await res.json();
      setMatchResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Terjadi kesalahan saat mencari kecocokan AI.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectFromHistory = (scan: ScanRecord) => {
    setSelectedScanId(scan.id);
    setCustomImageUrl(scan.imageUrl);
    setCustomImageName(scan.fileName);
    setMatchResult(null);
  };

  const handleCopyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2500);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-bold tracking-tight text-[#1E2E42]">
              Cari Kemiripan Model AI
            </h1>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
              <Globe className="w-3 h-3 text-emerald-600" />
              Live Web Search
            </span>
          </div>
          <p className="text-sm text-zinc-500">
            Mau tahu foto ini paling mirip gaya buatan AI mana? Kami cocokkan dengan model populer seperti Midjourney, Flux, SDXL, atau DALL-E.
          </p>
        </div>
      </div>

      {/* Select Image Bar / Picker */}
      <div className="bg-white rounded-xl border border-zinc-200 p-5 shadow-xs space-y-4">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-600 flex items-center gap-2">
          <ImageIcon className="w-4 h-4 text-[#1E2E42]" />
          <span>Pilih Foto yang Mau Dicari Kemiripannya</span>
        </h2>

        {/* Existing Scans Selector Thumbnails */}
        {scans.length > 0 ? (
          <div>
            <span className="text-[11px] text-zinc-500 block mb-2">
              Pilih foto dari riwayat cek kamu:
            </span>
            <div className="flex gap-2.5 overflow-x-auto pb-2">
              {scans.slice(0, 8).map((s) => {
                const isSelected = selectedScanId === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => handleSelectFromHistory(s)}
                    className={`relative shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all cursor-pointer group ${
                      isSelected
                        ? 'border-[#1E2E42] ring-2 ring-[#1E2E42]/20'
                        : 'border-zinc-200 hover:border-zinc-400 opacity-80 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={s.thumbnailUrl || s.imageUrl}
                      alt={s.fileName}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors" />
                    <span className="absolute bottom-1 left-1 right-1 text-[9px] font-medium text-white truncate drop-shadow-xs">
                      {s.label === 'ai' ? 'AI' : 'Human'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="text-xs text-zinc-500">
            Belum ada arsip pemindaian. Silakan unggah gambar di menu Upload terlebih dahulu.
          </div>
        )}

        {/* Action button to trigger real-time search */}
        <div className="pt-2 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between border-t border-zinc-100">
          <div className="flex items-center gap-3">
            {customImageUrl && (
              <img
                src={customImageUrl}
                alt="Active Target"
                className="w-10 h-10 rounded-md object-cover border border-zinc-200"
              />
            )}
            <div className="truncate">
              <span className="text-xs font-semibold text-zinc-800 block truncate max-w-xs">
                {customImageName}
              </span>
              <span className="text-[11px] text-zinc-500">
                Target analisis kemiripan model & visual
              </span>
            </div>
          </div>

          <button
            onClick={handleRunSearch}
            disabled={loading || !customImageUrl}
            className="inline-flex items-center justify-center gap-2 bg-[#1E2E42] hover:bg-[#162332] text-white px-5 py-2.5 rounded-lg text-xs font-semibold transition-all shadow-xs cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Mencari Kemiripan Real-Time...</span>
              </>
            ) : (
              <>
                <Search className="w-3.5 h-3.5" />
                <span>Cari Kemiripan AI & Model Serupa</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-zinc-100 border border-zinc-300 text-xs text-zinc-800">
          {error}
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && (
        <div className="bg-white rounded-xl border border-zinc-200 p-8 shadow-xs space-y-4 text-center">
          <div className="w-12 h-12 rounded-full bg-[#F0F4F8] text-[#1E2E42] flex items-center justify-center mx-auto animate-pulse">
            <BrandLogo size={28} variant="transparent" />
          </div>
          <h3 className="text-sm font-semibold text-zinc-800">
            Menghubungkan ke Google Search Grounding & Visual Classifier...
          </h3>
          <p className="text-xs text-zinc-500 max-w-md mx-auto">
            Membandingkan profil frekuensi piksel dengan parameter model Midjourney v6.1, Flux.1 Dev, SDXL, dan DALL-E 3 untuk mendeteksi karya serta generator yang paling identik.
          </p>
          <div className="w-48 h-1.5 bg-zinc-100 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-[#1E2E42] animate-pulse w-3/4" />
          </div>
        </div>
      )}

      {/* Match Results Display */}
      {matchResult && !loading && (
        <div className="space-y-6">
          {/* Top Model Match Card */}
          <div className="bg-white rounded-xl border border-zinc-200 shadow-xs overflow-hidden">
            <div className="p-6 md:p-8 space-y-6">
              <div className="flex flex-col md:flex-row gap-6 items-start">
                {/* Image Reference */}
                <div className="w-full md:w-5/12 rounded-xl overflow-hidden border border-zinc-200 bg-zinc-900/5 aspect-4/3 flex items-center justify-center shrink-0">
                  <img
                    src={customImageUrl || ''}
                    alt="Target Analisis"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>

                {/* Match Information */}
                <div className="w-full md:w-7/12 space-y-4">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 block mb-1">
                      Model AI yang Paling Mirip
                    </span>
                    <div className="flex items-center gap-3">
                      <h2 className="text-2xl font-bold text-[#1E2E42]">
                        {matchResult.topMatchedModel}
                      </h2>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#F0F4F8] border border-[#CBD5E1] text-[#1E2E42]">
                        {matchResult.matchConfidence}% Kemiripan
                      </span>
                    </div>
                    <p className="text-xs text-zinc-500 mt-1 font-mono">
                      Arsitektur: {matchResult.modelFamily}
                    </p>
                  </div>

                  {/* Summary */}
                  <div className="p-3.5 rounded-lg bg-[#F8F9FA] border border-zinc-200 text-xs text-zinc-700 leading-relaxed">
                    {matchResult.analysisSummary}
                  </div>

                  {/* Signature tags */}
                  <div className="space-y-2">
                    <span className="text-xs font-semibold text-zinc-800 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#1E2E42]" />
                      <span>Ciri Khas & Signature Visual Terdeteksi:</span>
                    </span>
                    <ul className="space-y-1.5">
                      {matchResult.identifiedSignatures.map((sig, idx) => (
                        <li
                          key={idx}
                          className="text-xs text-zinc-600 flex items-start gap-2 bg-zinc-50 p-2 rounded-md border border-zinc-100"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-[#1E2E42] mt-1.5 shrink-0" />
                          <span>{sig}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Quick Action: Animate into Video */}
                  <div className="pt-2 flex gap-3">
                    <button
                      onClick={() => {
                        if (onSelectForVeo && customImageUrl) {
                          onSelectForVeo(customImageUrl, customImageName);
                        }
                        onNavigate('veo-animate');
                      }}
                      className="inline-flex items-center gap-2 bg-[#1E2E42] hover:bg-[#162332] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer shadow-xs"
                    >
                      <Film className="w-3.5 h-3.5" />
                      <span>Animasikan Gambar Ini ke Video (Veo)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Reconstructed Prompt Clue */}
              <div className="pt-4 border-t border-zinc-100 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-800 flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Rekonstruksi Prompt Prediktif (Gaya Generator Serupa):</span>
                  </span>
                  <button
                    onClick={() => handleCopyPrompt(matchResult.reconstructedPrompt)}
                    className="inline-flex items-center gap-1 text-[11px] text-[#1E2E42] hover:underline font-medium cursor-pointer"
                  >
                    {copiedPrompt ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-700">Tersalin</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Salin Prompt</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="bg-zinc-900 text-zinc-200 font-mono text-xs p-3 rounded-lg border border-zinc-800 break-words">
                  {matchResult.reconstructedPrompt}
                </div>
              </div>
            </div>
          </div>

          {/* Similar Artworks Gallery */}
          <div className="bg-white rounded-xl border border-zinc-200 shadow-xs p-6 space-y-5">
            <div>
              <h2 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#1E2E42]" />
                <span>Karya & Gambar AI dengan Karakteristik Serupa</span>
              </h2>
              <p className="text-xs text-zinc-500 mt-0.5">
                Koleksi acuan benchmark karya buatan AI dengan kemiripan spektrum tekstur, pencahayaan, dan komposisi.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {matchResult.similarArtworks.map((art) => (
                <div
                  key={art.id}
                  className="rounded-xl border border-zinc-200 overflow-hidden bg-white hover:border-zinc-300 transition-all flex flex-col group shadow-xs"
                >
                  <div className="relative aspect-16/10 bg-zinc-100 overflow-hidden">
                    <img
                      src={art.previewUrl}
                      alt={art.title}
                      className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2">
                      <span className="bg-black/75 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-md border border-white/20">
                        {art.similarity}% Serupa
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2">
                    <div>
                      <span className="text-[10px] font-bold text-[#1E2E42] uppercase tracking-wider block">
                        {art.generator}
                      </span>
                      <h4 className="text-xs font-semibold text-zinc-800 line-clamp-1 mt-0.5">
                        {art.title}
                      </h4>
                      <p className="text-[11px] text-zinc-500 mt-1 line-clamp-2">
                        {art.styleTag}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-zinc-100">
                      <div className="text-[10px] text-zinc-500 font-mono line-clamp-2 bg-zinc-50 p-1.5 rounded-sm border border-zinc-100">
                        "{art.promptSnippet}"
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Web Search Grounding Sources */}
          {matchResult.searchSources && matchResult.searchSources.length > 0 && (
            <div className="bg-white rounded-xl border border-zinc-200 shadow-xs p-5 space-y-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-zinc-500" />
                <span>Referensi Sumber Web Terverifikasi (Google Search Grounding):</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {matchResult.searchSources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-zinc-50 hover:bg-[#F0F4F8] border border-zinc-200 transition-colors flex items-center justify-between text-xs text-zinc-800 group"
                  >
                    <span className="truncate pr-2 font-medium group-hover:text-[#1E2E42]">
                      {source.title}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-zinc-400 group-hover:text-[#1E2E42] shrink-0" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
