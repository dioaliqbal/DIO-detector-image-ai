import { detectWithSightengine, DetectionResult } from './sightengineDetector.ts';
import { detectAiImage } from './geminiDetector.ts';

export async function analyzeImageForensics(
  base64Data: string,
  mimeType: string = 'image/jpeg'
): Promise<DetectionResult> {
  // Primary engine: Sightengine API requested by user
  try {
    const sightengineResult = await detectWithSightengine(base64Data, mimeType);
    return sightengineResult;
  } catch (sightengineErr: any) {
    console.warn(
      'Sightengine API encountered an issue, gracefully falling back to Gemini Vision forensics:',
      sightengineErr?.message || sightengineErr
    );

    // Fallback engine: Gemini AI Vision
    try {
      const geminiResult = await detectAiImage(base64Data, mimeType);
      return {
        ...geminiResult,
        provider: 'Gemini Vision AI (Fallback)',
      };
    } catch (geminiErr: any) {
      console.error('All AI detection providers failed:', geminiErr);
      throw geminiErr;
    }
  }
}
